//Task 1

const Time = 
{
    minutes: 0,
    hours: 0,
    seconds: 0,

    toDisplayTime: function()
    {
        let hh = String(this.hours).padStart(2, '0');
        let mm = String(this.minutes).padStart(2, '0');
        let ss = String(this.seconds).padStart(2, '0');
        return `${hh}:${mm}:${ss}`;
    },

    addOneSecond: function()
    {
        this.seconds++;
        if(this.seconds >= 60)
        {
            this.seconds = 0;
            this.minutes++;
            if(this.minutes >= 60)
            {
                this.minutes = 0;
                this.hours++;
                if(this.hours >= 24)
                {
                    this.hours = 0;
                }
            }
        }       
    },

    substractOneSecond: function()
    {
        this.seconds--;
        if(this.seconds < 0)
        {
            this.seconds = 59;
            this.minutes--;
            if(this.minutes < 0)
            {
                this.minutes = 59;
                this.hours--;
                if(this.hours < 0)
                {
                    this.hours = 23;
                }
            }
        }
    },

    displayCurrentTime: function()
    {
        document.write(this.toDisplayTime());
    }
};

const time = Object.create(Time);
time.hours = 10;
time.minutes = 30;
time.seconds = 45;

time.displayCurrentTime();
time.addOneSecond();
time.displayCurrentTime();
time.substractOneSecond();
time.displayCurrentTime();


//Task 2

let car =
{
    brand: "Tesla",
    model: "Model S",
    year: 2021,
    avgSpeed: 100,
    displayInfo: function()
    {
        console.log(`Brand: ${this.brand}`);
        console.log(`Model: ${this.model}`);
        console.log(`Year: ${this.year}`);
        console.log(`Average Speed: ${this.avgSpeed}`);
    },

    calculateTravelTime: function (distance)
    {
        let travelTime = distance / this.avgSpeed;
        let breaks = Math.floor(travelTime / 4);
        let totalTravelTime = travelTime + breaks;
        return totalTravelTime;
    }
};

car.displayInfo();
console.log(`Time to cover 40 km: ${car.calculateTravelTime(400)} hours`);