
<div data-sound="/sound/click" class="loud-link-hover"></div>