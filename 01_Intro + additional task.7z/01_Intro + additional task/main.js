
//Task 1

alert("Hello Vlad :), Task 1 ");
const year = prompt('Enter your year of birth: ');
console.log(`Your old: ${ 2023 - year}`);

//Task 2

alert("Task 2");
const side = prompt('Enter radius circles: ');
console.log(`Area of circle: ${side ** 2}`);

//Task 3

alert("Task 3");
const km = prompt('Enter km between two cities: ');
const time = prompt('Enter time: ');
console.log(`Calculate speed: ${km / time}`);

//Task 4

alert("Task 4");
const number = prompt('Enter dollars: ');
console.log(`Convert to euro: ${number * 0.95} `);

//Task 5

alert("Task 5");
const memory = prompt('Enter memory of flash drive (on GB): ');
console.log(`Program calculate: ${memory *1000 / 820} `);




//+ practice
//Task 1

alert("Practice, Task 1");
const mile = +prompt('Enter kilomiters: ');
console.log(`Convert to miles: ${mile * 0.621371} `);


//Task 2

alert("Task 2");
const hours = prompt('Enter hours: ');
const minutes = prompt('Enter minutes: ');
console.log(`Times: ${23 - hours}:${59 - minutes}`);


