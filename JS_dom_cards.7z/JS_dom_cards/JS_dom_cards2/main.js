const suits = ['hearts', 'diamonds', 'clubs', 'spades']; 
const values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']; 
const deck = []; 

for (let suit of suits) 
{ 
    for (let value of values) 
    { 
        deck.push({suit, value}); 
    } 
} 
const shuffleDeck = (deck) => 
{ 
    for (let i = deck.length - 1; i > 0; i--) 
    { 
        const j = Math.floor(Math.random() * (i + 1)); 
        [deck[i], deck[j]] = [deck[j], deck[i]];
     } 
}; 

shuffleDeck(deck); 

const player1Cards = deck.slice(0, 6); 
const player2Cards = deck.slice(6, 12); 

const createCardElement = (card) => 
{ 
    const cardDiv = document.createElement('div'); 
    cardDiv.classList.add('card'); 
    cardDiv.style.backgroundImage = `url('images/${card.value}_of_${card.suit}.png')`; 
    return cardDiv; 
}; 
const player1Div = document.getElementById('player1'); 
const player2Div = document.getElementById('player2'); 

for (let card of player1Cards) 
{ 
    player1Div.appendChild(createCardElement(card)); 
} 

for (let card of player2Cards) 
{ 
    player2Div.appendChild(createCardElement(card)); 
}