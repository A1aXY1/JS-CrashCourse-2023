const form = document.querySelector("form");
      const carList = document.querySelector("#car-list");

      // Масив зі списком автомобілів
      let cars = [
        {
          model: "BMW X5",
          year: 2015,
          price: 25000,
          color: "Чорний",
          customs: true,
        },
        {
          model: "Toyota Camry",
          year: 2018,
          price: 15000,
          color: "Сірий",
          customs: false,
        },
        {
          model: "Mercedes-Benz S-Class",
          year: 2021,
          price: 100000,
          color: "Білий",
          customs: true,
        },
      ];

      // Функція для відображення списку автомобілів у вигляді таблиці
      function renderCarList() {
        carList.innerHTML = "";
        for (let car of cars) {
          const row = document.createElement("tr");
          const customsText = car.customs ? "Так" : "Ні";
          row.innerHTML = `<td>${car.model}</td>
                            <td>${car.year}</td>
                            <td>${car.price}</td>
                            <td>${car.color}</td>
                            <td>${customsText}</td>`;
          carList.appendChild(row);
        }
      }