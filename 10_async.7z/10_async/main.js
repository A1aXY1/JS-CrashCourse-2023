//Task 1
function getPromise(message, delay) 
{
    return new Promise(resolve => 
        {
            setTimeout(() => 
            {
                resolve(message);
            }, delay);
    });
}


//Task 2
function calcArrProduct(arr) 
{
    return new Promise((resolve, reject) => 
    {
      if (!Array.isArray(arr)) 
      {
        reject("Error! Incorrect array!");
      } 
      
      else 
      {
        const product = arr.reduce((acc, val) => 
        {
          if (typeof val !== "number") 
          {
            reject("Error! Incorrect array!");
          }
          return acc * val;
        }, 1);

        resolve(product);
      }
    });
}