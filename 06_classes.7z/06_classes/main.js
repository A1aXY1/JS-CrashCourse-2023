//Task2

class Button
{
    constructor(width, height, text)
    {
        this.width = width;
        this.height = height;
        this.text = text;
    }

    showBtn()
    {
        document.write(`<button style="width:${this.width}px; height:${this.height}px;">${this.text}</button>`);
    }
}

class BootstrapButton extends Button
{
    constructor(width, height, text, color)
    {
        super(width, height, text);
        this.color = color;
    }

    showBtn()
    {
        document.write(`<button class="btn btn-${this.color}" style="width:${this.width}px; height:${this.height}px;">${this.text}</button>`);
    }
}

//Task2

class ExtendedDate extends Date
{
    constructor(year, month, day)
    {
        super(year, month, day);
    }

    getDateText()
    {
        const months = ["січня","лютого","березня","квітня","травня","червня","липня","серпня","вересня","жовтня","листопада","грудня"];
        return `${this.getDate()} ${month[this.getMonth()]}`;
    }

    isFuture()
    {
        return this.getTime() > Date.now();
    }

    isLeapYear()
    {
        const year = this.getFullYear();
        return (year % 4 == 0 && year % 100 !== 0) || year % 400 === 0; 
    }

    getNextDate()
    {
        const nextDate = new ExtendedDate(this);
        next.Date.setDate(nextDate.getDate() + 1);
        return nextDate;
    }
}

const date = new ExtendedDate(2023, 3, 15);
 
console.log(date.getDateText());
console.log(date.isFuture());
console.log(date.isLeapYear());
console.log(date.getNextDate());

