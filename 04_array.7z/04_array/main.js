//Task 1

//1
const arr = new Array(20).fill(0).map(() => Math.floor(Math.random() * 100) + 1);

//2
arr.forEach((num, index) => console.log(`[${index + 1}] – ${num}`));

//3
arr.sort((a, b) => b - a);

//4
const halfLength = Math.floor(arr.length / 2);
arr.fill(0, halfLength);

//5
const isMultipleOf7 = arr.some(num => num % 7 === 0);
console.log(isMultipleOf7 ? 'Array contains a number that is a multiple of 7.' : 
'Array does not contain a number that is a multiple of 7.');

//6
arr.splice(0, 3);

//7
const countEvenNumbers = arr.reduce((count, num) => num % 2 === 0 ? count + 1 : count, 0);
console.log(`Number of even numbers in the array: ${countEvenNumbers}`);

//8
const hasDuplicates = arr.length !== new Set(arr).size;
console.log(hasDuplicates ? 'Array has duplicates.' : 'Array does not have duplicates.');



//Task 2

//1
const userInput = prompt("Enter a string:");
const spaceCount = userInput.split(" ").length - 1;
console.log(`Number of spaces in the string: ${spaceCount}`);

//2
function capitalizeFirstChar(str) 
{
    return str.charAt(0).toUpperCase() + str.slice(1);
}
  
const inputStr = "hello world";
const capitalizedStr = capitalizeFirstChar(inputStr);
console.log(capitalizedStr);

//3
const userInput = prompt("Enter a string:");
const wordCount = userInput.split(" ").length;
console.log(`Number of words in the string: ${wordCount}`);

//4
const userInput = prompt("Enter a phrase:");
const words = userInput.split(" ");
const abbreviation = words.map(word => word.charAt(0).toUpperCase()).join("");
console.log(`Abbreviation: ${abbreviation}`);

//5
function isPalindrome(str) 
{
    const reversedStr = str.split("").reverse().join("");
    return str === reversedStr;
}
  
const userInput = prompt("Enter a string:");
const isPalindromic = isPalindrome(userInput);
console.log(isPalindromic ? "Entered string is a palindrome." : "Entered string is not a palindrome.");