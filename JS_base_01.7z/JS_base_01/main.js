//Task 1

//1
let num = parseInt(prompt("Enter a number from 0 to 9:"));
let char;

switch(num){
  case 0:
    char = ")";
    break;
  case 1:
    char = "!";
    break;
  case 2:
    char = "@";
    break;
  case 3:
    char = "#";
    break;
  case 4:
    char = "$";
    break;
  case 5:
    char = "%";
    break;
  case 6:
    char = "^";
    break;
  case 7:
    char = "&";
    break;
  case 8:
    char = "*";
    break;
  case 9:
    char = "(";
    break;
  default:
    char = "Invalid input!";
}

alert(char);


//2
let year = parseInt(prompt("Enter a year:"));
let isLeapYear;

if(year % 400 === 0 || (year % 4 === 0 && year % 100 !== 0)){
  isLeapYear = true;
} else {
  isLeapYear = false;
}

alert(`Is ${year} a leap year? ${isLeapYear}`);


//3
let day = parseInt(prompt("Enter day:"));
let month = parseInt(prompt("Enter month:"));
let year = parseInt(prompt("Enter year:"));

let isLeapYear = (year % 400 === 0) || (year % 4 === 0 && year % 100 !== 0);
let daysInMonth = [31, (isLeapYear ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

if(day < 1 || day > daysInMonth[month-1]){
  alert("Invalid date!");
} else {
  day++;
  if(day > daysInMonth[month-1]){
    day = 1;
    month++;
    if(month > 12){
      month = 1;
      year++;
    }
  }
  alert(`The next date is: ${day}.${month}.${year}`);
}


//Task 2

//1
let start = parseInt(prompt("Enter the start number:"));
let end = parseInt(prompt("Enter the end number:"));
let sum = 0;

for(let i = start; i <= end; i++){
  sum += i;
}

alert(`The sum of all numbers from ${start} to ${end} is: ${sum}`);

//2
let number = parseInt(prompt("Enter a number:"));
let numDigits = 0;

while(number !== 0){
  number = Math.floor(number / 10);
  numDigits++;
}

alert(`The number of digits in the entered number is: ${numDigits}`);

//3
let positiveCount = 0;
let negativeCount = 0;
let zeroCount = 0;
let evenCount = 0;
let oddCount = 0;

for(let i = 0; i < 10; i++){
  let num = parseInt(prompt(`Enter number ${i + 1}:`));

  if(num > 0){
    positiveCount++;
  } else if(num < 0){
    negativeCount++;
  } else {
    zeroCount++;
  }

  if(num % 2 === 0){
    evenCount++;
  } else {
    oddCount++;
  }
}

alert(`Positive numbers: ${positiveCount}
Negative numbers: ${negativeCount}
Zeroes: ${zeroCount}
Even numbers: ${evenCount}
Odd numbers: ${oddCount}`);


//4
let weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
let index = 0;

do{
  let showNextDay = confirm(`${weekdays[index]}. Do you want to see the next day?`);
  if(showNextDay){
    index = (index + 1) % weekdays.length;
  }
}while(showNextDay);