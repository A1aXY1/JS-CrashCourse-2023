
//Task 1

alert("Hello Vlad :) ");
const year = prompt('Enter your year of birth: ');
console.log(`Your old: ${ 2023 - year}`);


//Task 2

const side = prompt('Enter radius circles: ');
console.log(`Area of circle: ${side ** 2}`);


//Task 3

const km = prompt('Enter km between two cities: ');
const time = prompt('Enter time: ');
console.log(`Calculate speed: ${km / time}`);


//Task 4

const number = prompt('Enter dollars: ');
console.log(`Convert to euro: ${number * 0.95} `);


//Task 5

const memory = prompt('Enter memory of flash drive (on GB): ');
console.log(`Program calculate: ${memory *1000 / 820} `);